<?php

namespace Billplz\Three;

use Billplz\Base\OpenCollection as Request;

class OpenCollection extends Request
{
    /**
     * Version namespace.
     *
     * @var string
     */
    protected $version = 'v3';
}
