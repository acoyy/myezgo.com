<?php

namespace Billplz\Three;

use Billplz\Base\BankAccount as Request;

class BankAccount extends Request
{
    /**
     * Version namespace.
     *
     * @var string
     */
    protected $version = 'v3';
}
