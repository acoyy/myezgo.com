<?php

namespace Billplz\Three;

use Billplz\Base\Bill as Request;

class Bill extends Request
{
    /**
     * Version namespace.
     *
     * @var string
     */
    protected $version = 'v3';
}
