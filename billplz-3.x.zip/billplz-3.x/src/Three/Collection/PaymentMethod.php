<?php

namespace Billplz\Three\Collection;

use Billplz\Base\Collection\PaymentMethod as Request;

class PaymentMethod extends Request
{
    /**
     * Version namespace.
     *
     * @var string
     */
    protected $version = 'v3';
}
