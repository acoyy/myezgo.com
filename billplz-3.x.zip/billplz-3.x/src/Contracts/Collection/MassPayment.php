<?php

namespace Billplz\Contracts\Collection;

/**
 * @deprecated v3.2.0
 * @see \Billplz\Contracts\Collection\Payout
 */
interface MassPayment extends Payout
{
    //
}
