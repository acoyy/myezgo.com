<?php

namespace Billplz\Contracts;

/**
 * @deprecated v3.2.0
 * @see \Billplz\Contracts\Payout
 */
interface MassPayment extends Payout
{
    //
}
