<?php

namespace Billplz\Four\Collection;

class MassPayment extends Payout
{
    //
}
