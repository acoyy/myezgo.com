<?php

namespace Billplz\Four\Collection;

use Billplz\Three\Collection\PaymentMethod as Request;

class PaymentMethod extends Request
{
    //
}
