<?php

namespace Billplz\Four\Bill;

use Billplz\Three\Bill\Transaction as Request;
use Billplz\Contracts\Bill\Transaction as Contract;

class Transaction extends Request implements Contract
{
    //
}
