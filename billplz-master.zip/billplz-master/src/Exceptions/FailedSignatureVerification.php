<?php

namespace Billplz\Exceptions;

use InvalidArgumentException;

class FailedSignatureVerification extends InvalidArgumentException
{
    //
}
