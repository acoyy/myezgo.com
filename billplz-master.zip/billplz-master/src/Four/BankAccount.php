<?php

namespace Billplz\Four;

use Billplz\Three\BankAccount as Request;

class BankAccount extends Request
{
    //
}
