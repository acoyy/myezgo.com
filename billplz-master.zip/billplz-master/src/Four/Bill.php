<?php

namespace Billplz\Four;

use Billplz\Three\Bill as Request;

class Bill extends Request
{
    //
}
