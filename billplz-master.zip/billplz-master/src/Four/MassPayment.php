<?php

namespace Billplz\Four;

/**
 * @deprecated v3.2.0
 *
 * @see \Billplz\Contracts\Payout
 */
class MassPayment extends Payout
{
    //
}
