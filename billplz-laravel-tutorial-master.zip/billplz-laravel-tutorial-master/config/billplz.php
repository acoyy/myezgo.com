<?php

return [
    'billplz_key' => env('BILLPLZ_KEY'),
    'billplz_signature' => env('BILLPLZ_SIGNATURE'),
    'billplz_collection_id' => env('BILLPLZ_COLLECTION_ID'),
    'billplz_sandbox' => env('BILLPLZ_SANDBOX'),
];